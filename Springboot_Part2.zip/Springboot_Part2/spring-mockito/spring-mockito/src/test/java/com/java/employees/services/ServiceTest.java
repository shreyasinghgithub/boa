package com.java.employees.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.java.employees.dao.EmployeeRepository;
import com.java.employees.model.Employee;

@ExtendWith(MockitoExtension.class)
public class ServiceTest {
 
	@InjectMocks
	EmployeeService service;
	@Mock
	EmployeeRepository repository;
	
	public void init() {
		MockitoAnnotations.openMocks(this);
	}
	@Test
	public void testEmpFind() {
		List<Employee> data= new ArrayList<Employee>();
		data.add(new Employee("alex", "andrew"));
		data.add(new Employee("mathew", "han"));
		data.add(new Employee("steve", "steve"));
		// init the dummy data with mocking
		Mockito.when(repository.findAll()).thenReturn(data);
		List<Employee> emplist= service.findAll();
		assertEquals(3, emplist.size());
		
		
	}
	
}