package com.model;

public interface Restaurant {
 public String preapre(String dish);
}
