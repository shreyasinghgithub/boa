package com.model;

public class IndianRestaurant implements Restaurant {

	@Override
	public String preapre(String dish) {
		// TODO Auto-generated method stub
		return "prepare " + dish +" with Indian spices";
	}

}
