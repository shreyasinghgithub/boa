package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.service.RestaurantService;

public class RestaurantClient {

	public static void main(String[] args) {
	//initialize the container
	ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
	//load the service class
	RestaurantService bs = (RestaurantService)ctx.getBean("service");
	
    System.out.println(bs.prepareOrder("dosa"));
	}	
}
