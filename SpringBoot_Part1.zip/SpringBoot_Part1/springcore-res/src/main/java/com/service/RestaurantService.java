package com.service;

import com.model.Restaurant;

public class RestaurantService {
 public Restaurant res;

public Restaurant getRes() {
	return res;
}

public void setRes(Restaurant res) {
	this.res = res;
} 
 
public String prepareOrder(String dish){
	return res.preapre(dish);
	
}
}
