package com.service;

import java.util.List;

import com.entity.Employee;

public interface EmpService {
	
	public void addEmp(Employee emp);
	
	public List<Employee> loadAll();
	
	public boolean findEmp(int empNo);
	
	public boolean deleteEmp(int empNo);
	
	public void updateEmp(int empno, String empname);

}
