package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;
import com.model.UsersApp;

@Service
public class UserServiceImpl implements UserServices{
	private static UsersApp list = new UsersApp();
	static {
		list.getUser().add(new Users("admin", "admin123", "admin@123", "pune"));
		list.getUser().add(new Users("admin1", "admin123", "admin@123", "pune"));
	}
	

	@Override
	public UsersApp getAll() {
		// TODO Auto-generated method stub
		return list;
	}


	@Override
	public void addUser(Users user) {
		list.getUser().add(user);
		
	}

	
}
