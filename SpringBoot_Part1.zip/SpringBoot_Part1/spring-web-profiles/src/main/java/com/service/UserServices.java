package com.service;

import java.util.List;

import com.model.Users;

public interface UserServices {
  
	public boolean loginValid(String uname,String pass);
	
	public void registerUser(Users user);
	
	public List<Users> loadAll();
	
	public boolean findUser(String name);
	
	public boolean deleteUser(String name);
	
	public void updateUser(String name,Users user);
}
