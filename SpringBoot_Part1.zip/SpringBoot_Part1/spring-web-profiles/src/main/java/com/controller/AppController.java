package com.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserServices;


@RestController
@RequestMapping("/mainapp")
public class AppController {
	
	@Autowired
	public UserServices service;
     
	@PostMapping("/login")
	public String loginValid(@RequestBody Users user) {
		String uname = user.getUname();
		String pwd = user.getPass();
		if(service.loginValid(uname, pwd)) {
			return "login success";
		}
		return "login failed";
	}
	
	
	@PostMapping("/register")
	public String registerUser(@RequestBody Users user) {
	service.registerUser(user);
	return "User Registered";
	}
	
	@GetMapping("/loadusers")
	public List<Users> loadUsers(){
		return service.loadAll();
	}
	
	@GetMapping("/finduser/{uname}")
	public String findUserDetails(@PathVariable String uname) {
		if(service.findUser(uname)) {
			return uname+" is  found and available!";
		}
		return uname+" not found.....!";
	}
	
	@DeleteMapping("/deleteuser/{uname}")
	public String deleteUserDetails(@PathVariable String uname) {
		if(service.deleteUser(uname)) {
			return uname+" is  found and deleted!";
		}
		return uname+" not found.....!";
	}
	
	@PutMapping("/updateuser/{uname}")
	public String updateUserDetails(@PathVariable String uname,@RequestBody Users user) {
		service.updateUser(uname,user);
			return uname+" is  found and updated!";
		
	}
}
