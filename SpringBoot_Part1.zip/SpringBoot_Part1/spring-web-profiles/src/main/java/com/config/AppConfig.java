package com.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@ConfigurationProperties("spring.ds")
public class AppConfig {
	private String driverclass;
	private String url;
	private String username;
	private String password;
	public String getDriverclass() {
		return driverclass;
	}
	public void setDriverclass(String driverclass) {
		this.driverclass = driverclass;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Bean
	@Profile("dev")
	private String devDBConfig() {
		System.out.println("Getting dev env enabled");
		System.out.println(driverclass);
		System.out.println(driverclass);
		System.out.println(driverclass);
		return "DEV CONNECTED !!";
	}
	@Bean
	@Profile("prod")
	private String prodDBConfig() {
		System.out.println("Getting dev env enabled");
		System.out.println(driverclass);
		System.out.println(driverclass);
		System.out.println(driverclass);
		return "PROD CONNECTED !!";
	}
	@Bean
	@Profile("test")
	private String testDBConfig() {
		System.out.println("Getting dev env enabled");
		System.out.println(driverclass);
		System.out.println(driverclass);
		System.out.println(driverclass);
		return "TEST CONNECTED !!";
	}
	@Bean
	@Profile("preprod")
	private String preprodDBConfig() {
		System.out.println("Getting dev env enabled");
		System.out.println(driverclass);
		System.out.println(driverclass);
		System.out.println(driverclass);
		return "PREPROD CONNECTED !!";
	}
}
