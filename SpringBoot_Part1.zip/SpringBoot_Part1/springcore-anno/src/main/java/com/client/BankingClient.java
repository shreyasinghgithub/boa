package com.client;


import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.service.BankingService;

public class BankingClient {

	public static void main(String[] args) {
	//initialize the container
	ConfigurableApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
	//load the service class
	BankingService bs = (BankingService)ctx.getBean("service");
	
    //double amt = bs.calculateApp(2345);
    System.out.println(bs.calculateApp(2345));

    ctx.close();
	}	
}
