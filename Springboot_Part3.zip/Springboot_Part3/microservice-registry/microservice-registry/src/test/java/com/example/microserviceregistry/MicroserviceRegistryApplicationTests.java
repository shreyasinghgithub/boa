package com.example.microserviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
