package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Employee;
import com.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmpService {

	@Autowired
	private EmployeeRepo repo;
	@Override
	public void addEmp(Employee emp) {
		// TODO Auto-generated method stub
		repo.save(emp);
		
	}
	@Override
	public List<Employee> loadAll() {
		
		return (List<Employee>)repo.findAll();
	}
	
	@Override
	public boolean findEmp(int empNo) {
		Optional<Employee> op = repo.findById(empNo);
		if(op.isPresent()) {
			return true;
		}
	
		return false;
	}
	@Override
	public boolean deleteEmp(int empNo) {
		Optional<Employee> op = repo.findById(empNo);
		if(op.isPresent()) {
			repo.deleteById(empNo);
			return true;
		}
	
		return false;
	}
	
	@Override
	public void updateEmp(int empno, String empname) {
		 repo.updateEmp(empname, empno);
		
	}

}
