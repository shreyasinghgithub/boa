package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Employee;
import com.service.EmpService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
 
	@Autowired
	private EmpService service;
	
	@PostMapping("/addemp")
	public ResponseEntity createEmployee(@RequestBody Employee emp) {
		service.addEmp(emp);;
		return ResponseEntity.ok("Employee Added Successfully!!");
	}
	
	@GetMapping("/loadAll")
	public List<Employee> findAll(){
		return service.loadAll();
	}
	
	@GetMapping("/findById/{id}")
	public String findByID(@PathVariable Integer id){
		if(service.findEmp(id)) {
			return "Employee Found !!";
		}
		return "Employee Not Found !!";
		
	}
	
	@DeleteMapping("/deleteById/{id}")
	public String deleteByID(@PathVariable Integer id){
		if(service.findEmp(id)) {
			return "Employee Found and Deleted!!";
		}
		return "Employee Not Found so can't be deleted!!";
		
	}
	@PutMapping("/updateuser/{empid}/{empname}")
	public String updateUser(@PathVariable int empid,@PathVariable String empname) {
		service.updateEmp(empid, empname);
		return "user found.... and updated!";
	}
  
}
