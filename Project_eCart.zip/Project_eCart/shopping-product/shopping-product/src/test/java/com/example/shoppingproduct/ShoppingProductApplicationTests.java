package com.example.shoppingproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
