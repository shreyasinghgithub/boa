package com.example.shoppinggateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
